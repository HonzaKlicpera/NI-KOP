﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KnapsackProblem.Common
{
    public class KnapsackItem
    {
        public int Id { get; set; }
        public int Weight { get; set; }
        public int Price { get; set; }
    }
}
